This folder should contain assets for the game, such as images or sound.
The build process actually REQUIRES there to be assets present in this folder.
If you are not using assets in your game (???) then you will need a
placeholder file in this folder. This file can serve that purpose.